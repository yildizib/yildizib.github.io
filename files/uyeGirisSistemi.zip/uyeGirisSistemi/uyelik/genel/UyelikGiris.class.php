<?php
require_once 'ISistemeGirisAdaptor.class.php';
/**
 *
 * @author yildizib
 *
 */
class UyelikGiris implements ISistemeGirisAdaptor{
	/**
	 *
	 * @var unknown_type
	 */
	private $adaptor ;
	/**
	 *
	 * @param $adaptor
	 * @return unknown_type
	 */
	public function __construct($adaptor){
		if($adaptor == null){
			throw new Exception("Adaptör nesnesi nerede?");
		}

	 $this->adaptor = $adaptor;
	}
	/**
	 * (non-PHPdoc)
	 * @see uyelik/genel/ISistemeGirisAdaptor#girisOnaylandiMi()
	 */
	public function girisOnaylandiMi(){
		return $this->adaptor->girisOnaylandiMi();
	}
	/**
	 * (non-PHPdoc)
	 * @see uyelik/genel/ISistemeGirisAdaptor#girisYapilmisMi()
	 */
	public function girisYapilmisMi(){
		return $this->adaptor->girisYapilmisMi();
	}
	/**
	 * (non-PHPdoc)
	 * @see uyelik/genel/ISistemeGirisAdaptor#getirMesajlari()
	 */
	public function getirMesajlari(){
		return $this->adaptor->getirMesajlari();
	}
}
?>