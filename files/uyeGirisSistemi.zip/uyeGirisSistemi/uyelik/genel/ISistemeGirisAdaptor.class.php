<?php
/**
 *
 * @author yildizib
 *
 */
interface ISistemeGirisAdaptor{
	/**
	 *
	 * @return unknown_type
	 */
	public function girisOnaylandiMi();
	/**
	 *
	 * @return unknown_type
	 */
	public function girisYapilmisMi();
	/**
	 *
	 * @return unknown_type
	 */
	public function getirMesajlari();

}
?>