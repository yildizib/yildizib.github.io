<?php
require_once '../ISistemeGirisAdaptor.class.php';
/**
 *
 * @author yildizib
 *
 */
class BenimGirisAdaptorum implements ISistemeGirisAdaptor{
	/**
	 *
	 * @var unknown_type
	 */
	private $kuladi;
	/**
	 *
	 * @var unknown_type
	 */
	private $sifre;
	/**
	 *
	 * @var unknown_type
	 */
	private $girisTamam = false;
	/**
	 *
	 * @return unknown_type
	 */
	public function __construct($kuladi, $sifre){
		$this->kuladi = $kuladi;
		$this->sifre = $sifre;
	}
	/**
	 * (non-PHPdoc)
	 * @see uyelik/genel/ISistemeGirisAdaptor#girisOnaylandiMi()
	 */
	public function girisOnaylandiMi(){
		$this->girisTamam = true;
		return true;
	}
	/**
	 * (non-PHPdoc)
	 * @see uyelik/genel/ISistemeGirisAdaptor#girisYapilmisMi()
	 */
	public function girisYapilmisMi(){
		return $this->girisTamam;
	}
	/**
	 * (non-PHPdoc)
	 * @see uyelik/genel/ISistemeGirisAdaptor#getirMesajlari()
	 */
	public function getirMesajlari(){
		return new ArrayObject("Mesajlar");
	}
}
?>