<?php
/**
 * Sisteme Giriş örneği
 */
require_once '../UyelikGiris.class.php';
require_once 'BenimGirisAdaptorum.php';

$giris = new UyelikGiris(new BenimGirisAdaptorum("assd", "123"));

if($giris->girisYapilmisMi()){
	echo "Evet\n";
}else{
	echo "Hayır\n";
}

if($giris->girisOnaylandiMi()){
	echo "Onaylandı\n";
}

if($giris->girisYapilmisMi()){
	echo "Evet\n";
}else{
	echo "Hayır\n";
}
?>